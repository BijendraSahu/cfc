




<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

<?php echo Form::open(['url'=>'branches', 'id'=>'frEnq']); ?>

<div class="container-fluid">
    <div class="col-sm-6">
        <h3 class="bg-info text-center">Branch Info</h3>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('Branch', 'Branch Name *', ['class' => 'col-sm-5 control-label']); ?>

            <div class='col-sm-7'>
                <?php echo Form::text('branchname', null, ['class' => 'form-control input-sm input-sm textWithSpace required', 'placeholder'=>'Branch Name']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('addr', 'Address *', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('address', null, ['class' => 'form-control input-sm input-sm textWithSpace required', 'placeholder'=>'Address']); ?>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('name', 'City', ['class'=>'col-sm-5 form-label']); ?>

            <div class="col-sm-7">
                <?php echo e(Form::text('city', null, ['class' => 'form-control input-sm textWithSpace required', 'placeholder'=>'City'])); ?>

            </div>
        </div>
        <p class="clearfix"></p>

        <div class="form-group">
            <?php echo Form::label('name', 'State', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('state', null, ['class' => 'form-control input-sm', 'placeholder'=>'State']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
    </div>
    <div class="col-sm-6">
        <h3 class="bg-info text-center">Create Admin Panel</h3>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('Userid', 'User Name', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('username', null, ['class' => 'form-control input-sm required', 'placeholder'=>'User Name']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('id', 'Contact', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('contact', null, ['class' => 'form-control input-sm contact numberOnly required', 'placeholder'=>'Contact No']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('id', 'Login ID', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('userid', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Login ID']); ?>

            </div>
        </div>
        <p class="clearfix"></p>
        <div class="form-group">
            <?php echo Form::label('any_requirement', 'Password', ['class' => 'col-sm-5 control-label']); ?>

            <div class="col-sm-7">
                <?php echo Form::text('password', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Password']); ?>

            </div>
        </div>
    </div>
    <p class="clearfix"></p>
    <p class="clearfix"></p>
    <div class="col-sm-12">
        <div class="form-group">
            <div class="">
                <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary btn-xs btn-block','id'=>"commitBtn"])); ?>

            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>


<script>
    $(function () {
        $('.dtp').datepicker({
            format: "dd-MM-yyyy",
            maxViewMode: 2,
            todayBtn: "linked",
            daysOfWeekHighlighted: "0",
            autoclose: true,
            todayHighlight: true,
//            minDate: 0,
            minDate: new Date()
        });
    });


    (function ($, window, document, undefined) {
        $("#duration").on("change", function () {
            var date = new Date($("#traveldate").val()),
                duration = parseInt($("#duration").val(), 10);
            if (!isNaN(date.getTime())) {
                date.setDate(date.getDate() + duration - 1);
                $(".enddate").val(date.toInputFormat());
                $("#enddate").html(date.toInputFormat());
            } else {
                alert("Invalid Tour End Date");
            }
        });
        //From: http://stackoverflow.com/questions/3066586/get-string-in-yyyymmdd-format-from-js-date-object
        Date.prototype.toInputFormat = function () {
            var yyyy = this.getFullYear().toString();
            var MM = (this.getMonth() + 1).toString(); // getMonth() is zero-based
            var dd = this.getDate().toString();
            return (dd[1] ? dd : "0" + dd[0]) + "-" + (MM[1] ? MM : "0" + MM[0]) + "-" + yyyy; // padding
        };
    })(jQuery, this, document);
</script>