<?php $__env->startSection('title','KOT List'); ?>

<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
    
    
    
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    
    
    <h3 class="heading bg-success">KOT List with Tables</h3>
    <?php echo Form::open(['url' => 'stock', 'class' => 'form-horizontal', 'id'=>'user_master']); ?>

    <div class="light bordered">

        
        
        <p class="clearfix"></p>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    <!-- Begin page content -->
        <div class="container-fluid">
            
            <div class="grid simple">

                <div>
                    <p class="clearfix"></p>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="">Booked Table List<b class="star">*</b></label>
                            <?php echo Form::select('table_id', $booked_tables, null,['class' => 'form-control table_id input-sm requiredDD']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <p class="clearfix"></p>
        <div id="msg" class="alert-danger"></div>
        <h3>Item List</h3>
        <p class="msg bg-primary"></p>
        
        <div id="table_list" class="container-fluid">

        </div>

        <div class="col-md-12">
            <div class="text-center">
                <div id="divMsg" style="display:none;">
                    
                    <div id="progress">Please wait...</div>
                </div>
                <br>
                
                
                
                
                
                        
                    
                
                
                
                
                <p id="err"></p>
            </div>
            <br/>
        </div>
        <?php echo Form::close(); ?>

        <p class="clearfix"></p>
        
    </div>
    <script>

        $('.table_id').change(function () {
            $('#table_list').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            var tableId = $('.table_id').val();
//            alert(tableId);
            if (tableId == 0) {
                alert('Please Select Table');
                $('.table_id').focus();
                $('#btnConfirm').hide();
                return false;
            }
            $('#btnConfirm').show();
            var send_to_url = '<?php echo e(url('/')); ?>' + "/kot/" + tableId + "/filter";
//            alert(send_to_url);
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: send_to_url,
                success: function (data) {
                    $("#table_list").html(data);
                },
                error: function (xhr, status, error) {
                    //alert('Error occurred');
                    $("#table_list").html(xhr.responseText);
                }
            });
        });

        function submitChange() {
//        var cpassword = $('#cpswd').val();
            var table_id = $('.table_id').val();
//            alert(table_id);
            var formData = '_token=' + $('.token').val();
            if (table_id == '0') {
//            alert('Please enter your rc.');
//            $('.rcode').focus();
                $('#btnConfirm').hide();
                return false;
            } else {
                $.ajax({
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "<?php echo e(url('print_bill')); ?>",
//                data: '{"data":"' + endid + '"}',
                    data: '{"formData":"' + formData + '", "table_id":"' + table_id + '"}',
                    success: function (data) {
//                        if (data == 'ok') {
                        console.log(data);
                        $('#table_id').val('0');
                        var yourDOCTYPE = "<!DOCTYPE html>"; // your doctype declaration
                        var printPreview = window.open('about:blank', 'print_preview', "resizable=yes,scrollbars=yes,status=yes");
                        var printDocument = printPreview.document;
                        printDocument.open();
                        printDocument.write(yourDOCTYPE +
                            "<html>" +
                            data +
                            "</html>");
                        printDocument.close();

//                        $('.statusMsg').html('<span style="color:green;">Password changed successfully</p>');
//                        } else if (data == 'Incorrect') {
//                            $('#txtChange_previousPsd').val('');
//                            $('.statusMsg').html('<span style="color:red;">Incorrect current password</span>');
//                        }
                    },
                    error: function (xhr, status, error) {
//                    alert('xhr.responseText');
                        $('#err').html(xhr.responseText);
                    }
                });
            }
        }

        $(document).ready(function () {
            $('#frmStock').submit(function () {
                $('#divMsg').show();
                $('#progress').show();
                $('.btn').disable();

            });
        });
        function placeOrder(form) {
            form.submit();
        }
    </script>
    <style>
        #progress {
            display: none;
            color: green;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>