<div>
    <?php if(count($issues)>0): ?>
        <table id="dtTable" class="table table-bordered table-condensed">
            <thead>
            <tr class="bg-info text-center">
                <th width="5%">S.No</th>
                <th>Item</th>
                <th>Unit</th>
                <th>Qty</th>
            </tr>
            </thead>
            <tbody>
            <?php $i = 1;?>
            <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    
                    <td><?php echo e($item->itemName->ItemName); ?></td>
                    <td><?php echo e($item->itemName->menuUnit->UnitName); ?></td>
                    
                    <td><?php echo e($item->qty); ?></td>
                </tr>
                <?php $i++;?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No Record Available</p>
    <?php endif; ?>
</div>