<style>
    .right_txt {
        text-align: right;
    }

    .btndd {
        margin: 3px 0px;
        padding: 2px 3px;
    }

    .btnul a {
        padding: 3px 5px !important;
        font-size: 12px;
        border-bottom: solid thin #ccc;
    }

    .btnul {
        width: 120px;
        min-width: 100px;
        padding: 0px;
    }

    .btnula {
        padding: 3px 5px !important;
    }
</style>
<table id="" class="table-bordered" cellspacing="0" width="100%">
    <thead>
    <tr class="bg-info">

        <th class="text-center">S.No</th>
        <th class="text-center">Item Name</th>
        <th class="text-center">Qty</th>
        <th class="text-center">Rate</th>
        <th class="text-center">Amount</th>
        <th class="text-center">Status</th>
        <th class="text-center">Option</th>

    </tr>
    </thead>
    <tbody>
    <?php $counter = 1; $net_amount = 1;?>
    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center">
            <td><?php echo e($counter); ?></td>
            <td><?php echo e($item->m_name); ?></td>
            <td><?php echo e($item->qty); ?></td>
            <td><?php echo e($item->price); ?></td>
            <td><?php echo e($item->total); ?></td>
            <td><?php echo e($item->total); ?></td>
            <td>
                <div class="btn-group action">
                    <button type="button" class="btn btn-sm btn-success btndd dropdown-toggle"
                            data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">Options
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul id="<?php echo e($item->id); ?>" class="btn-sm btnul dropdown-menu">
                        <li><a href="#" id="<?php echo e($item->id); ?>" class="order-change btnadda"><i class="fa fa-pencil
                                        text-info">&nbsp;</i>Update Qty</a>
                        </li>
                        <?php if($item->is_cancelled == 0): ?>
                            <li><a href="#" id="<?php echo e($item->id); ?>" class="mark-cancel btnadda"><i class="fa fa-eye
                                        text-info">&nbsp;</i>Mark As Cancel</a>
                            </li>
                        <?php endif; ?>
                        <?php if($item->is_complementary == 0): ?>
                            <li><a href="#" id="<?php echo e($item->id); ?>" class="mark-Complementary btnadda"><i class="fa fa-eye
                                        text-info">&nbsp;</i>Complementary</a>
                            </li>
                        <?php else: ?>
                            <p class="bg-success">Complementary</p>
                        <?php endif; ?>

                    </ul>
                </div>
            </td>
        </tr>
        <?php $counter++; $net_amount += $item->total; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </tbody>
</table>
<script>


    $(".order-change").click(function () {
        $('#myModal').modal('show');
        $('.modal-title').html('Edit Order Items');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(this).attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/order_item/" + id + "/edit";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
                $('.modal-body').html(xhr.responseText);
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    });

    $(".mark-cancel").click(function () {
        $('#myModal').modal('show');
        $('.modal-title').html('Cancel Order');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(this).attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/order_item/" + id + "/cancel";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
                $('.modal-body').html(xhr.responseText);
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    });

    $(".mark-Complementary").click(function () {
        $('#myModal').modal('show');
        $('.modal-title').html('Cancel Order');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(this).attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/order_item/" + id + "/complementary";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
                $('.modal-body').html(xhr.responseText);
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    });

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

</script>