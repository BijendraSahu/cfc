<?php $__env->startSection('title','List of Menu Items'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(url('Menu')); ?>" class="btn btn-sm bg-danger btnSet btn-primary pull-right">
        <span class="fa fa-eye"></span>Menu List</a>
    <h3 class="heading">Create Menus</h3>
    <hr/>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php echo Form::open(['url' => 'Menu', 'class' => 'form-horizontal', 'id'=>'Menus', 'files'=>true]); ?>

    <div class="container-fluid">
        <div class="container-fluid">
            <div class="col-sm-6">

                <div class='form-group'>
                    <?php echo Form::label('name', 'Menu Name *', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::text('name', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Menu Name']); ?>

                    </div>
                </div>
                <div class='form-group'>
                    <?php echo Form::label('Description', 'Description', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::text('description', null, ['class' => 'form-control input-sm  ', 'placeholder'=>'Description']); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('Percent', 'Tax Percent*', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::select('percent_id', $percent, null,['class' => 'typeDD']); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('tour_image', 'Menu Image*',  ['class' => 'col-sm-4 control-label', 'type'=>'file', 'accept'=>'image/*']); ?>

                    <div class="col-sm-8">
                        <?php echo Form::file('menu_img', null, ['class' => 'control-label input-sm required', 'type'=>'file', 'accept'=>'image/*']); ?>

                    </div>
                </div>

            </div>
            <div class="col-sm-6">

                <div class="form-group">
                    <?php echo Form::label('role', 'Sub Category*', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::select('ddlcat', $cate, null,['class' => 'typeDD']); ?>

                    </div>
                </div>


                <div class='form-group'>
                    <?php echo Form::label('at', 'Act Price *', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::text('actprice', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Actual Price']); ?>

                    </div>
                </div>
                <div class='form-group'>
                    <?php echo Form::label('sp', 'Sale Price *', ['class' => 'col-sm-4 control-label']); ?>

                    <div class='col-sm-8'>
                        <?php echo Form::text('saleprice', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Sale Price']); ?>

                    </div>
                </div>
                <div class='form-group'>
                    <div class='col-sm-offset-4 col-sm-8'>
                        <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>