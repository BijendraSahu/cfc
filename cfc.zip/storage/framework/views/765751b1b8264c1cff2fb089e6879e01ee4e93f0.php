<?php $__env->startSection('title','List of Itineraries'); ?>

<?php $__env->startSection('content'); ?>
    
    
    <a href="<?php echo e(url('tour/0/create')); ?>" class="btn btn-sm bg-danger btnSet btn-primary add-tour btnSet pull-right">
        <span class="fa fa-plus"></span>&nbsp;Create New Tour</a>
    <h3 class="heading bg-success">List of Tour</h3>
    <hr/>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <div class="row fa-border">
        <div class="container-fluid">
            <table id="" class="display compact" cellspacing="0" width="100%">
                <thead>
                <tr class="bg-info">
                    <th class="hidden">Id</th>
                    <th class="options">Options</th>
                    <th>Lead Info</th>
                    <th>Tour Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Total Days</th>
                    
                </tr>
                </thead>
                <tbody>
                <?php if(count($tours)>0): ?>
                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="hidden"><?php echo e($tour->id); ?></td>
                            <td id="<?php echo e($tour->id); ?>">
                                <div class="btn-group action">
                                    <button type="button" class="btn btn-sm btn-success dropdown-toggle"
                                            data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">Options
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul id="<?php echo e($tour->id); ?>" class="dropdown-menu">
                                        <li><a href="tour/<?php echo e($tour->id); ?>/itinerary" class="view-list"><i class="fa fa-plus
                                        text-info">&nbsp;</i>Generate Itinerary</a>
                                        </li>
                                        <li><a href="<?php echo e(url('itinerary').'/'.$tour->id); ?>/print" target="_blank"
                                               class="">
                                                <span class="fa fa-print"></span> Print Itinerary</a>
                                        </li>
                                        <li><a href="#" class=""><span class="fa fa-envelope"></span> Mail Itinerary</a>
                                        </li>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </ul>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </td>
                            <td><?php echo e($tour->lead_master->name); ?>, <?php echo e($tour->lead_master->contact); ?>

                                , <?php echo e($tour->lead_master->email); ?></td>
                            <td><?php echo e($tour->tour_name); ?></td>
                            <td><?php echo e(date_format(date_create($tour->start_date), "d-M-Y")); ?></td>
                            <td><?php echo e(date_format(date_create($tour->end_date), "d-M-Y")); ?></td>
                            <td><?php echo e($tour->total_days); ?></td>
                            
                            
                            
                            
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <br/>
    <script>
        $('.btnDelete').click(function () {
            var id = $(this).attr('id');
            $('#myModal').modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#myModal .modal-title').html('Confirm Deletion');
            $('#myModal .modal-body').html('<h5>Are you sure want to delete this tour<h5/>');
            $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('tour')); ?>/' + id +
                '/delete"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        });
        
            
            
            
            
            
                
                
                
                
                    

                
                
                    
                    
                
            

        
        $(".edit-tour_").click(function () {
            $('#myModal').modal('show');
            $('.modal-title').html('Edit Tour');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

            var id = $(this).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/tour/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        });

        $(document).ready(function () {
            var table = $('#dataTable').DataTable({
                "columnDefs": [
                    {"width": "20px", "targets": 0}
                ]
            });

            $('.datatable-col').on('keyup change', function () {
                table.column($(this).attr('id')).search($(this).val()).draw();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>