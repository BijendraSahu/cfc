

<div id="example_wrapper" class="dataTables_wrapper">
    
        
    
<table id="example" class="table-bordered" cellspacing="0" width="100%">
    <thead>
    <tr class="bg-info">
        <th class="text-center">Enquiry#</th>
        <th class="text-center">Category</th>
        <th class="text-center">Name</th>
        <th class="text-center">Contact Info</th>
        <th class="text-center">Created On</th>
        <th class="text-center">Last Visited</th>
        <th class="text-center">Next Followup Date</th>
        <th class="text-center">Amount</th>
        <th class="text-center">Loan Status</th>
        <th class="text-center">Status</th>
        <th class="text-center">Allocated To</th>
        
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php echo e(($item->is_completed == 1 && $item->is_converted == 1) ? 'bg-success' : ''); ?> text-center">
            <td><?php echo e($item->enquiry_master->full_enquiry_no); ?></td>
            <td><?php if($item->enquiry_master->enquiry_category_id != null): ?><?php echo e($item->enquiry_master->enquiry_category->category_name); ?><?php else: ?>
                    - <?php endif; ?></td>
            <td title="Remark- <?php echo e($item->enquiry_master->any_requirement); ?>"><?php echo e($item->name); ?></td>
            <td><?php echo e($item->contact); ?>, <?php echo e($item->email); ?>, <?php echo e(is_null($item->address)? " - " : $item->address); ?></td>
            <td><?php echo e(($item->created_date == null)? " - " :  date_format(date_create($item->created_date),"d-M-Y")); ?></td>
            <td><?php echo e(($item->last_visited_date == null)? " - " : date_format(date_create($item->last_visited_date), "d-M-Y")); ?></td>
            <td><?php echo e(($item->next_followup_date == null)? " - " : date_format(date_create($item->next_followup_date), "d-M-Y")); ?></td>
            <td><?php echo e(($item->amount == null)? " - " : $item->amount); ?></td>
            <td><?php echo e(($item->loan_status == null)? " - " : $item->loan_status); ?></td>
            <td><?php echo e(($item->lead_status_id == null)? " - " : $item->lead_status->status); ?></td>
            <td><?php echo e(($item->user_master_id == null)? " - " : $item->user_master->name); ?></td>
            
                
                    
                       
                    
                    
                    
                    
                
                
                
                
                   
                   
                
                   
                
                
                   
                
                   
                   
                
                
                    
                       
                
                    
                       
                    
                    
                       
                    
                    
                       
                    
                
                
                    
                       
                       
                

                
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<script type="text/javascript">
    //function ExportGrid() {
       // alert("vghvdbdl vshgkjs");
        //window.open('data:application/vnd.ms-excel,' + $('#example').html());

    //}

    $(function () {
        $("#btnExport").click(function () {
            $("#example1").table2excel({
                filename: "Your_File_Name.xls"
            });
        });
    });

    $(document).ready(function () {
        $(".assign").click(function () {
            $('#myModal').modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#myModal .modal-title').html('Assign To Executive');
            var id = $(this).parent().attr('id');
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_cLeadAssgn')); ?>",
                data: '{"data":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Technical Error Occurred");
                }
            });
        });
        $('.btnDelete').click(function () {
            var id = $(this).attr('id');
            $('#myModal').modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#myModal .modal-title').html('Confirm Deletion');
            $('#myModal .modal-body').html('<h5>Are you sure want to delete this Lead<h5/>');
            $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('lead')); ?>/' + id +
                '/delete"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        });

        $(".edit-lead_").click(function () {
            $('#myModal').modal('show');
            $('.modal-title').html('Edit Lead');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

            var id = $(this).parent().attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/lead/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        });

        $(".edit-enquiry_").click(function () {
            $('#myModal').modal('show');
            $('.modal-title').html('Edit Enquiry');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

            var id = $(this).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        });
        $(".view-enquiry_").click(function () {
            $('#myModal').modal('show');
            $('.modal-title').html('View Enquiry Details');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

            var id = $(this).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/enquiry/" + id;
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (xhr, status, error) {
                    $('.modal-body').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        });
    });

</script>


<script>
    $(".delete_lead").click(function () {
        $('#myModal').modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        var id = $(this).parent().attr('id');
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_clsLead')); ?>",
            data: '{"data":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Technical Error Occurred");
            }
        });
    });
</script>

<script>
    $(document).ready(function () {
        //$('#example').DataTable();
        var table = $('#example').DataTable();

        $('#example tbody')
            .on('mouseenter', 'td', function () {
                var colIdx = table.cell(this).index().column;

                $(table.cells().nodes()).removeClass('highlight');
                $(table.column(colIdx).nodes()).addClass('highlight');
            });
    });

    //    $(".view-comment").click(this, function () {
    //        $('#myModal').modal('show');
    //        $('.modal-title').html('Communication Process');
    //        $('.modal-body').html($(this).parent().find('.comments').html());
    //
    //    });


    $(".view-comment").click(this, function () {
        $('#myModal').modal('show');
        $('.modal-title').html('Communication Process');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');

        var id = $(this).parent().attr('id');
        var editurl = '<?php echo e(url('/')); ?>' + "/lead/" + id + "/add";
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: editurl,
            data: '{"data":"' + id + '"}',
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (xhr, status, error) {
                $('.modal-body').html(xhr.responseText);
                //$('.modal-body').html("Technical Error Occured!");
            }
        });
    });
</script>

<script type="text/javascript">

    $(".btnFollowUp").click(function () {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
        var id = $(this).parent().attr('id');
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gflwupfrm')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Error Occurred");
            }
        });
    });
    $(".btnConvert").click(function () {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
        var id = $(this).parent().attr('id');
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gCnvtFrm')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Error Occurred");
            }
        });
    });
    $(".btnNoReponse").click(function () {
        $("#myModal").modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
        var id = $(this).parent().attr('id');
        $.ajax({
            type: "post",
            contentType: "application/json; charset=utf-8",
            url: "<?php echo e(url('_gNRF')); ?>",
            data: '{"id":"' + id + '"}',
            //dataType: "json",
            success: function (data) {
                $('.modal-body').html(data);
            },
            error: function (result) {
                $('.modal-body').html("Error Occurred");
            }
        });
    });



</script>
