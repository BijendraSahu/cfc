<?php $__env->startSection('title','Create Stock'); ?>

<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
    
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php if(Session::has('success-msg')): ?>
        <p class="alert alert-success"><?php echo e(Session::get('success-msg')); ?></p>
    <?php endif; ?>
    <a href="<?php echo e(url('stock')); ?>" class="btn btn-sm bg-danger btnSet btn-primary add-tour btnSet pull-right">
        <span class="fa fa-eye"></span>&nbsp;Go Back</a>
    <h3 class="heading bg-success">Create Stock</h3>
    <?php echo Form::open(['url' => 'stock', 'class' => 'form-horizontal', 'id'=>'user_master']); ?>

    <div class="light bordered">

        
        
        <p class="clearfix"></p>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
    <?php endif; ?>


    <!-- Begin page content -->
        <div class="container-fluid">
            
            <div class="grid simple">
                <div>
                    <p class="clearfix"></p>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Stock No.# <b class="star">*</b>: &nbsp;</label>
                            
                            
                            
                            
                            
                            <?php echo Form::text('stock_no', $stock_no, ['class' => 'form-control input-sm input-sm required', 'placeholder'=>'Date', 'onkeypress'=>'return false','id'=>'stock_no','readonly'=>true]); ?>

                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Bill/Challan Date<b class="star">*</b>: &nbsp;</label>
                            
                            
                            
                            
                            <?php echo Form::text('date', null, ['class' => 'form-control input-sm input-sm dtp required', 'placeholder'=>'Date', 'onkeypress'=>'return false','id'=>'payment_date']); ?>

                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Bill No: &nbsp;</label>
                            
                            
                            
                            
                            
                            <?php echo Form::text('bill_no', null, ['class' => 'form-control input-sm input-sm', 'placeholder'=>'Bill No.', 'id'=>'bill_no']); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Challan No: &nbsp;</label>
                        
                        
                        
                        
                        
                        <?php echo Form::text('challan_no', null, ['class' => 'form-control input-sm input-sm', 'placeholder'=>'Challan No.', 'id'=>'challan_no']); ?>

                    </div>
                </div>

            </div>
            <div>
                <p class="clearfix"></p>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="">Supplier Name<b class="star">*</b></label>
                        
                        
                        
                        
                        
                        
                        
                        <?php echo Form::select('supplier_id', $suppliers, null,['class' => 'form-control input-sm requiredDD']); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>Description: &nbsp;</label>
                    <textarea class="form-control input-sm" name="material_description"
                              id="material_description"
                              placeholder="Material Description" rows='3'></textarea>
                    
                </div>
            </div>
            
            
            
            

            
            
        </div>
    </div>
    
    <p class="clearfix"></p>
    <div id="msg" class="alert-danger"></div>
    <h3>Item List</h3>
    <p class="msg bg-primary"></p>

    
    <div class="container-fluid">
        <table id="itemTable" class="table table-bordered table-responsive">
            <thead>
            <tr class="bg danger">
                <th width="2%"><input id="check_all" type="checkbox"/></th>
                <th class="hidden">Product Id</th>
                <th>PARTICULARS</th>
                <th>Unit</th>
                <th>QTY</th>
                <th>RATE</th>
                <th>GST%</th>
                <th>GST AMT</th>
                <th>AMOUNT</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><input class="case" type="checkbox"/></td>
                <td class="hidden">
                    <input type="text" class="form-control input-sm" id="itemId_1" name="itemId[]">
                </td>
                <td>
                    <input type="text" tabindex="7" class="form-control input-sm auto-text required"
                           placeholder="Search Items by Name"
                           id="itemName_1" name="itemName[]">
                    
                    
                    
                    
                    
                    
                    
                    
                </td>
                <td>
                    <input type="text" tabindex="-1" class="form-control input-sm required"
                           placeholder="Item Unit" readonly="readonly"
                           id="itemUnit_1" name="itemUnit[]">
                </td>

                <td>
                    <input type="text" class="form-control input-sm changesNo value-change pqty required numberOnly"
                           placeholder="Quantity"
                           id="quantity_1" tabindex="8" name="quantity[]">
                </td>
                <td>
                    <input type="text" class="form-control input-sm changesNo rate amount required" placeholder="Rate"
                           id="itemRate_1" tabindex="9" name="itemRate[]">
                    <input type="hidden" class="form-control input-sm changesNo rate" placeholder="Rate"
                           id="itemR_1" tabindex="-1" name="itemR[]">
                    <input type="hidden" class="form-control input-sm amount required" placeholder="itemAmt"
                           id="itemAmt_1" tabindex="9" name="itemAmt[]">
                </td>
                <td>
                    <input type="text" class="form-control input-sm changeGst amount required" placeholder="GST%"
                           id="itemGst_1" name="itemGst[]" tabindex="9" maxlength="5">
                </td>
                <td>
                    <input type="text" class="form-control input-sm amount required" placeholder="GST Amt"
                           id="itemGstAmt_1" readonly="readonly" name="itemGstAmt[]">
                </td>
                
                
                
                
                <td>
                    <input type="text" class="form-control input-sm row-total" placeholder="Amount"
                           readonly="readonly" id="itemAmount_1" tabindex="-1" name="itemAmount[]">
                </td>
            </tr>
            </tbody>
        </table>
        <p class="clearfix"></p>
        <button class="btn btn-sm btn-success addmore" tabindex="11" type="button"><span
                    class="fa fa-plus"></span>&nbsp;
        </button>
        <button class="btn btn-sm btn-danger delete" tabindex="12" type="button"><span
                    class="fa fa-minus"></span>&nbsp;
        </button>
        
        
        
        
        
        

    </div>

    <div class="col-md-offset-6 col-md-6">
        <div class="row">
            <div class="col-md-offset-4 col-md-3">
                <label>Total Amount:</label>
            </div>
            <div class="col-md-5">
                <input type="text" class="form-control input-sm quotAmt" name="quotAmt" id="quotAmt"
                       placeholder="Total Amount"
                       onkeypress="return IsNumeric(event);" readonly="readonly" ondrop="return false;"
                       onpaste="return false;">
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="text-center">
            <div id="divMsg" style="display:none;">
                
                <div id="progress">Please wait...</div>
            </div>
            <br>
            
            
            
            <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

            <a class="btn btn-default" onclick="javascript:history.back();"><span
                        class=""></span>&nbsp;Back
            </a>
        </div>
        <br/>
    </div>
    <?php echo Form::close(); ?>

    <p class="clearfix"></p>
    
    <script>
        $(document).ready(function () {
            $('#frmStock').submit(function () {
                $('#divMsg').show();
                $('#progress').show();
                $('.btn').disable();

            });
        });
        function placeOrder(form) {
            form.submit();
        }
    </script>
    <style>
        #progress {
            display: none;
            color: green;
        }
    </style>

    <script src="<?php echo e(url('assets/js/auto_stock_info.js')); ?>"></script>
    <script>

        $(document).on('focus', '.auto-text', function () {
            $(this).autocomplete({
                source: '<?php echo e(url('gpdetail')); ?>/1',
                minLength: 1,
                autoFocus: true,
                select: function (e, ui) {
//                    alert();
//                    console.log(ui);
                    id_arr = $(this).attr('id');
                    id = id_arr.split("_");
                    $('#itemId_' + id[1]).val(ui.item.id);
                    $('#itemName_' + id[1]).val(ui.item.item_name);
                    $('#itemUnit_' + id[1]).val(ui.item.UnitName);
//                    $('#itemGst_' + id[1]).val(ui.item.gst_per);
//                    $('#itemRate_' + id[1]).val(ui.item.item_rate);
//                    $('#itemR_' + id[1]).val(ui.item.item_rate);
//                    $('#quantity_' + id[1]).val(1);
//                    $('#itemUnit_' + id[1]).val(ui.item.size_unit);
                }
            });
        });

        //deletes the selected table rows
        $(".delete").on('click', function () {
            alert($('.case:checkbox:checked').parents("tr").prop('id'));
//            calculateQuotationTotal();
            calculateGrandTotal();
//            calculateVatPercent();
        });


        ///itemAmt += $('#itemAmt_' + id[1]).val((parseFloat(rate) * parseFloat(quantity)).toFixed(2));
        //        itemGstAmt += $('#itemGstAmt_' + id[1]).val((parseFloat(rate) * parseFloat(quantity) * parseFloat(gst) / 100).toFixed(2));
        //        itemAmount += $('#itemAmount_' + id[1]).val((parseFloat(rate) * parseFloat(quantity) * parseFloat(gst)) / 100 + ((parseFloat(rate) * parseFloat(quantity)).toFixed(2)));


        $(document).on('change', '.rate', function () {
            id_arr = $(this).attr('id');
            id = id_arr.split("_");
            itemAmt = 0;
            itemGstAmt = 0;
            itemAmount = 0;
            rate = $('#itemR_' + id[1]).val();
            enter_rate = $('#itemRate_' + id[1]).val();
            if (parseFloat(enter_rate) < parseFloat(rate)) {
                $('#itemRate_' + id[1]).val(parseFloat(rate));
//                $('.msg').text('Enter Qty is more than available Quantity');
            } else {
                $('.msg').text('');
            }
        });
        //rate change
        $(document).on('change keyup blur', '.changesNo', function () {
            id_arr = $(this).attr('id');
            id = id_arr.split("_");
            itemAmt = 0;
            itemGstAmt = 0;
            itemAmount = 0;
            quantity = $('#quantity_' + id[1]).val();
            rate = $('#itemRate_' + id[1]).val();
            gst = $('#itemGst_' + id[1]).val();
            if (quantity != '' && rate != '') {
                itemAmt += (parseFloat(rate) * parseFloat(quantity)).toFixed(2);
                itemGstAmt += (parseFloat(itemAmt) * parseFloat(gst) / 100).toFixed(2);
                itemAmount += (parseFloat(itemGstAmt) + parseFloat(itemAmt)).toFixed(2);
                $('#itemAmt_' + id[1]).val(parseFloat(itemAmt));
                $('#itemGstAmt_' + id[1]).val(parseFloat(itemGstAmt));
                $('#itemAmount_' + id[1]).val(parseFloat(itemAmount));
            }
            calculateQuotationTotal();
//            calculateGrandTotal();
            //calculateVatPercent();

//            id_arr = $(this).attr('id');
//            id = id_arr.split("_");
//            quantity = $('#quantity_' + id[1]).val();
//            rate = $('#itemRate_' + id[1]).val();
//            if (quantity != '' && rate != '') {
//                $('#itemAmount_' + id[1]).val((parseFloat(rate) * parseFloat(quantity)).toFixed(2));
//            }
//            calculateQuotationTotal();
//            calculateGrandTotal();
//            calculateVatPercent();
        });
        //
        //        // Transportation Total calculation
        function calculateQuotationTotal() {
            quotAmt = 0;
            $('.row-total').each(function () {
                if ($(this).val() != '') quotAmt += parseFloat($(this).val());
            });
            $('#quotAmt').val(quotAmt.toFixed(2));
        }

        // VAT Amount and Grand Total calculation
        //        $(document).on('change keyup blur', '.vat_percent', function () {
        //            calculateVatPercent();
        //        });
        //
        //        function calculateVatPercent() {
        //            vat_amount = 0;
        //            grand_total = 0;
        //            vat_percent = parseFloat($('.vat_percent').val());
        //            quotAmt = $('.quotAmt').val();
        //            $('.vat_percent').each(function () {
        //                vat_amount += (quotAmt * ( parseFloat(vat_percent) / 100 ));
        //            });
        //            $('#vat_amount').val(vat_amount.toFixed(2));
        //            grand_total = parseFloat(quotAmt) + parseFloat(vat_amount);
        //            $('#grand_total').val(grand_total.toFixed(2));
        //
        //        }
        //
        //        //Grand Total calculation
        //        function calculateGrandTotal() {
        //            grand_total = 0;
        //            $('.row-total').each(function () {
        //                if ($(this).val() != '')grand_total += parseFloat($(this).val());
        //            });
        //            $('#grand_total').val(grand_total.toFixed(2));
        //        }
    </script>
    
    
    
    
    
    
    
    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>