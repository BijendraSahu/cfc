<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
<?php if($errors->any()): ?>
    <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php echo Form::open(['url' => 'Tbl', 'class' => 'form-horizontal', 'id'=>'Tbl_Table']); ?>

<div class="container-fluid">
    <div class="container-fluid">
        <div class="col-sm-6">

            <div class='form-group'>
                <?php echo Form::label('name', 'Table No *', ['class' => 'col-sm-3 control-label']); ?>

                <div class='col-sm-8'>
                    <?php echo Form::text('name', null, ['class' => 'form-control input-sm required', 'placeholder'=>'Table No']); ?>

                </div>
            </div>

            <div class='form-group'>
                <div class='col-sm-offset-3 col-sm-8'>
                    <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php echo Form::close(); ?>

