<?php echo Form::open(['url'=>'_gldNR/'.$lead->id, 'id'=>'frmNoReponse']); ?>

<?php echo $__env->make('includes.communication_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">

    
    
        
    
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <?php echo Form::submit('Send Response', ['class' => 'btn btn-sm btn-primary']); ?>

        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>





















