<?php $__env->startSection('title','Table Settlement'); ?>

<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>
    
    
    

    
    
    <h3 class="heading bg-success">Shift Open/close</h3>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div role='alert' id='alert' class='alert alert-danger'><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php echo Form::open(['url' => 'shift', 'class' => 'form-horizontal', 'id'=>'shift']); ?>

    <div class="light bordered">

    
    
    <!-- Begin page content -->
        <div class="container-fluid">
            
            <div class="grid simple">

                <div>
                    <p class="clearfix"></p>
                    <div class="col-md-12">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">Shift Date<b class="star">* </b></label>
                                <?php echo e($user->opening_date != null ? date_format(date_create($user->opening_date), "d-M-Y h:i A") : "-"); ?>

                            </div>
                        </div>
                        <div class="col-md-1"></div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <br>
                                <?php echo e($user->opening_date != null ? Form::submit('Close Shift', ['class' => 'btn btn-sm btn-primary']) : Form::submit('Open Shift', ['class' => 'btn btn-sm btn-primary'])); ?>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>