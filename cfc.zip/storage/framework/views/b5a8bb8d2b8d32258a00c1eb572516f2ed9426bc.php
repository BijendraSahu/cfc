<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

<?php if(!is_null($order_item)): ?>
    <?php echo Form::open(['url' => 'order_item/'.$order_item->id.'/update', 'class' => 'form-horizontal', 'id'=>'Unit', 'method'=>'post', 'files'=>true]); ?>

    <div class="container-fluid">
        <div class="col-sm-12">
            <div class='form-group'>
                <?php echo Form::label('Menu', 'Menu Name', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-8'>
                    <p></p>
                    <label for=""><?php echo e($order_item->m_name); ?></label>
                </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('qty', 'Qty *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-8'>
                    <?php echo Form::text('qty', $order_item->qty, ['class' => 'form-control input-sm required','placeholder'=>'Quantity']); ?>

                </div>
            </div>
            <div class='form-group'>
                <div class='col-sm-offset-2 col-sm-8'>
                    <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>

<?php else: ?>
    <h4>Unit not found !</h4>
<?php endif; ?>
<script>
    $(function () {
        $('.dtp').datepicker({
            format: "dd-M-yyyy",
            maxViewMode: 2,
            todayBtn: "linked",
            daysOfWeekHighlighted: "0",
            autoclose: true,
            todayHighlight: true
        });
    });
</script>