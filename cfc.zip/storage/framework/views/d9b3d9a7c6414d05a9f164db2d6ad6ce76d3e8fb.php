
<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

<form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="<?php echo e(url('uploadExcel')); ?>"
      class="form-horizontal" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    
    <div class="form-group">
        <?php echo Form::label('role', 'Select Executive *', ['class' => 'col-sm-3 control-label']); ?>

        <div class='col-sm-9'>
            <?php echo Form::select('user_master_id', $users, null,['class' => 'form-control requiredDD']); ?>

        </div>
    </div>
    <div class="form-group">
        <div class = 'col-sm-3 control-label']>

        </div>
            <div class='col-sm-9'>
                <input type="file" name="import_file"/>
                <button class="btn btn-primary">Import File</button>
            </div>>
    </div>
</form>