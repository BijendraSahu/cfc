<?php $__env->startSection('title','List of Lead'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h3>Lead Lists</h3>
        
        
        
        
        <table id="dataTable" class="display compact" cellspacing="0" width="100%">
            <thead>
            <tr class="bg-info">
                <th>Operations</th>
                <th>Enquiry#</th>
                <th>Name</th>
                <th>Contact Info</th>
                
                <th>Address</th>
                <th>Created On</th>
                <th>Last Visited</th>
                <th>Next Followup Date</th>
                <th>Status</th>
                <th>Communication</th>
                
                
                
                
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td id="<?php echo e($item->id); ?>">
                        <a href="#" class="btn btn-sm btn-primary btn-xs btnFollowUp">
                            <span class="glyphicon glyphicon-cloud"></span> Need FollowUp
                        </a>
                        <a href="#" class="btn btn-sm btn-success btn-xs btnConvert">
                            <span class="glyphicon glyphicon-check"></span> Converted
                        </a>
                        <a href="#" class="btn btn-sm btn-danger btn-xs btnNoReponse">
                            <span class="glyphicon glyphicon-cloud"></span> No Response
                        </a>
                    </td>
                    <td><?php echo e($item->enquiry_master->full_enquiry_no); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->contact); ?>,<br/><?php echo e($item->email); ?>,<br/><?php echo e($item->address); ?></td>
                    
                    <td><?php echo e(($item->address == null)? " - " : $item->address); ?></td>
                    <td><?php echo e(($item->created_date == null)? " - " :  date_format(date_create($item->created_date),"d-M-Y")); ?></td>
                    <td><?php echo e(($item->last_visited_date == null)? " - " : date_format(date_create($item->last_visited_date), "d-M-Y")); ?></td>
                    <td><?php echo e(($item->next_followup_date == null)? " - " : date_format(date_create($item->next_followup_date), "d-M-Y")); ?></td>
                    <td><?php echo e(($item->lead_status_id == null)? " - " : $item->lead_status->status); ?></td>
                    <td><a href="#" class="text-success btn-sm btn-success glyphicon glyphicon-eye-open view-comment"
                           title="View Communication"><strong></strong></a>
                        <div id="comment" class="comments hidden"><?php echo $item->communication; ?></div>
                    </td>

                    
                    
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        $(".btnFollowUp").click(function () {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
            var id = $(this).parent().attr('id');
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gflwupfrm')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Error Occurred");
                }
            });
        });
        $(".btnConvert").click(function () {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
            var id = $(this).parent().attr('id');
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gCnvtFrm')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Error Occurred");
                }
            });
        });
        $(".btnNoReponse").click(function () {
            $("#myModal").modal('show');
            $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(URL::asset('img/loading.gif')); ?>"/>');
            var id = $(this).parent().attr('id');
            $.ajax({
                type: "post",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('_gNRF')); ?>",
                data: '{"id":"' + id + '"}',
                //dataType: "json",
                success: function (data) {
                    $('.modal-body').html(data);
                },
                error: function (result) {
                    $('.modal-body').html("Error Occurred");
                }
            });
        });

        
            
            
            
            
            
                
                
                
                
                    

                
                
                    
                    
                
            

        
        $(".view-comment").click(this, function () {
            $('#myModal').modal('show');
            $('.modal-title').html('Communication Process');
            $('.modal-body').html($(this).parent().find('.comments').html());

        });

        $(document).ready(function () {
            var table = $('#dataTable').DataTable({
                "columnDefs": [
                    {"width": "20px", "targets": 0}
                ]
            });

            $('.datatable-col').on('keyup change', function () {
                table.column($(this).attr('id')).search($(this).val()).draw();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>