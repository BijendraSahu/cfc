<div class="container">
    <?php echo Form::open(['url' => 'lead/'.$lead->id.'/update', 'id' => 'frmUpadte', 'method' => 'POST']); ?>


    <div class="row">
        <div class="form-groups">
            <?php echo Form::label('name', 'Select Executive',['class'=>'col-sm-2 control-label']); ?>

            <div class="col-sm-10">
                <?php if(!is_null($counsellor)): ?>
                    <?php echo Form::select('user_master_id', $counsellor, null,['class' => 'form-control requiredDD']); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="form-groups">
            <?php echo Form::label('name', 'Communication', ['class' => 'col-sm-2 control-label']); ?>

            <div class="col-sm-10">
                <?php echo Form::textarea('communication', null, ['class' => 'form-control', 'placeholder'=>'Communication', 'size'=>'50x4']); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="form-groups">
            <div class="col-offset-10 col-sm-12">
                <?php echo e(Form::submit('Submit',['class' => 'btn btn-primary'])); ?>

            </div>
        </div>
    </div>


    <?php echo Form::close(); ?>

</div>

<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

