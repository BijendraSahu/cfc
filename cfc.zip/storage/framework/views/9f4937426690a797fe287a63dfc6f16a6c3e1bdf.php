<?php if(count($tour_infoes)): ?>
    <?php $__currentLoopData = $tour_infoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="thumbnail">
                    <div class="caption">
                        <button type="button" id="<?php echo e($tour_info->id); ?>"
                                class="btn btn-sm btn-danger btn-xs btnDelete btnSet pull-right" title="Delete"><span
                                    class="fa fa-trash-o" aria-hidden="true"></span>Remove
                        </button>
                        <h3 class="bg-info text-center">Selected Day Description</h3>
                        <p class="clearfix"></p>
                        <h5><b>DAY:</b>
                            <?php if($tour_info->sentence_master_id != null): ?>  <?php echo e($tour_info->sentence_master->sentence); ?>

                            <?php endif; ?>
                        </h5>
                        <hr>
                        <?php if($tour_info->hotel_master_id != null): ?>
                            <h3 class="text-center">HOTEL:
                                <?php echo e($tour_info->hotel_master->hotel_name); ?>

                            </h3>
                            <table id="dataTable" class="display table">
                                <thead>
                                <tr class="bg-info">
                                    <th>Room Type & Inclusion</th>
                                    <th>Room Rate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tour_event_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e($event->hotel_info->room_type); ?></td>
                                        <td><i class="fa fa-inr"></i> <?php echo e($event->hotel_info->rate); ?></td>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div role='alert' id='alert' class='alert alert-danger'>No Event Found In Selected Day</div>
<?php endif; ?>
<script>
    $('.btnDelete').click(function () {
        var id = $(this).attr('id');
        $('#myModal').modal('show');
        $('.modal-body').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
        $('#myModal .modal-title').html('Confirm Remove');
        $('#myModal .modal-body').html('<h5>Are you sure want to remove this Description<h5/>');
        $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('itinerary_event')); ?>/' + id +
            '/delete"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
        );
    });
</script>














































